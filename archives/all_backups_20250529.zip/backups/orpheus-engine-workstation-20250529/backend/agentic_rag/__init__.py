"""
This file initializes the agentic_rag package.
"""